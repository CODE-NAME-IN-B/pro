import Layout from '../components/Layout';
import Header from '../components/Header';

interface Term {
  name: string;
  attendance: {
    present: number;
    total: number;
  };
  subjects: {
    name: string;
    grades: {
      qtr1: string;
      qtr2: string;
      term: string;
    };
  }[];
}

const terms: Term[] = [
  {
    name: 'Term I',
    attendance: {
      present: 235,
      total: 249,
    },
    subjects: [
      {
        name: 'English',
        grades: { qtr1: 'A+/96', qtr2: 'A+/96', term: 'A+/96' },
      },
      {
        name: 'Mathematics',
        grades: { qtr1: 'A+/94', qtr2: 'A+/94', term: 'A+/94' },
      },
      {
        name: 'Science',
        grades: { qtr1: 'A+/95', qtr2: 'A+/95', term: 'A+/95' },
      },
    ],
  },
  {
    name: 'Term II',
    attendance: {
      present: 235,
      total: 249,
    },
    subjects: [
      {
        name: 'English',
        grades: { qtr1: 'A+/96', qtr2: 'A+/96', term: 'A+/96' },
      },
      {
        name: 'Mathematics',
        grades: { qtr1: 'A+/94', qtr2: 'A+/94', term: 'A+/94' },
      },
      {
        name: 'Science',
        grades: { qtr1: 'A+/95', qtr2: 'A+/95', term: 'A+/95' },
      },
    ],
  },
];

export default function ProgressReport() {
  return (
    <Layout>
      <Header title="Progress Report" />
      <div className="p-4 space-y-6">
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <div className="text-center mb-6">
            <h2 className="text-xl font-semibold">Performance Profile</h2>
            <div className="flex items-center justify-center gap-4 mt-4">
              <img
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100"
                alt="Profile"
                className="w-20 h-20 rounded-full"
              />
              <div className="text-left">
                <h3 className="font-medium">Sarah Johnson</h3>
                <p className="text-sm text-gray-500">Roll Number: 42</p>
                <p className="text-sm text-gray-500">Class X-B</p>
              </div>
            </div>
          </div>

          {terms.map((term) => (
            <div key={term.name} className="mb-6">
              <h3 className="font-medium mb-4">{term.name}</h3>
              
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-500 mb-2">Attendance</h4>
                <div className="bg-green-100 p-3 rounded-lg text-green-700">
                  {term.attendance.present}/{term.attendance.total} Days
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-gray-500 mb-2">Academic Performance</h4>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left text-sm text-gray-500">
                        <th className="pb-2">Subject</th>
                        <th className="pb-2">Qtr 1</th>
                        <th className="pb-2">Qtr 2</th>
                        <th className="pb-2">Term</th>
                      </tr>
                    </thead>
                    <tbody>
                      {term.subjects.map((subject) => (
                        <tr key={subject.name} className="border-t">
                          <td className="py-2 font-medium">{subject.name}</td>
                          <td className="py-2">{subject.grades.qtr1}</td>
                          <td className="py-2">{subject.grades.qtr2}</td>
                          <td className="py-2">{subject.grades.term}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ))}

          <div className="mt-6 p-4 bg-orange-50 rounded-lg">
            <h4 className="font-medium text-orange-700 mb-2">Remarks by Teacher</h4>
            <p className="text-sm text-orange-600">
              Sarah has shown excellent progress throughout the year. Her consistent performance and active participation in class activities have been remarkable.
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
}