import Layout from '../components/Layout';
import Header from '../components/Header';

interface Notice {
  id: number;
  title: string;
  date: string;
  image: string;
}

const notices: Notice[] = [
  {
    id: 1,
    title: 'School is going for vacation in next month',
    date: '22 March 2024',
    image: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=200',
  },
  {
    id: 2,
    title: 'Summer Book Fair at School Campus in June',
    date: '22 March 2024',
    image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&q=80&w=200',
  },
];

export default function NoticeBoard() {
  return (
    <Layout>
      <Header title="Notice Board" />
      <div className="p-4 grid gap-4">
        {notices.map((notice) => (
          <div key={notice.id} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <img
              src={notice.image}
              alt={notice.title}
              className="w-full h-32 object-cover rounded-lg mb-3"
            />
            <h3 className="font-medium mb-1">{notice.title}</h3>
            <p className="text-sm text-gray-500">{notice.date}</p>
          </div>
        ))}
      </div>
    </Layout>
  );
}