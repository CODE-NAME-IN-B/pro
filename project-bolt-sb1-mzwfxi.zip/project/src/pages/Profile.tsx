import Layout from '../components/Layout';
import Header from '../components/Header';
import { Home, User, Calendar, Bell, Settings, LogOut, UserCircle } from 'lucide-react';

const menuItems = [
  { icon: Home, label: 'Home', path: '/dashboard' },
  { icon: User, label: 'Profile', path: '/profile' },
  { icon: Calendar, label: 'Calendar', path: '/calendar' },
  { icon: Bell, label: 'Notification', path: '/notifications' },
  { icon: Settings, label: 'Settings', path: '/settings' },
];

export default function Profile() {
  return (
    <Layout>
      <Header title="Profile" />
      <div className="p-4 space-y-6">
        <div className="flex flex-col items-center">
          <div className="relative">
            <div className="w-24 h-24 bg-gray-200 rounded-full overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100"
                alt="Profile"
                className="w-full h-full object-cover"
              />
            </div>
            <button className="absolute bottom-0 right-0 bg-primary text-white p-2 rounded-full">
              <UserCircle size={20} />
            </button>
          </div>
          <h2 className="mt-4 text-xl font-semibold">Sarah Johnson</h2>
          <p className="text-gray-500">Class X-B</p>
        </div>

        <div className="space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.label}
              className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 rounded-lg"
            >
              <item.icon size={20} className="text-primary" />
              <span>{item.label}</span>
            </button>
          ))}
          
          <button className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 rounded-lg text-red-500">
            <LogOut size={20} />
            <span>Log out</span>
          </button>
        </div>
      </div>
    </Layout>
  );
}