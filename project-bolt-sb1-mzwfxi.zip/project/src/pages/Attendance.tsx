import { useState } from 'react';
import Layout from '../components/Layout';
import Header from '../components/Header';
import { Calendar as CalendarIcon } from 'lucide-react';

interface AttendanceDay {
  date: number;
  status: 'present' | 'absent' | 'leave' | 'none';
}

export default function Attendance() {
  const [selectedMonth] = useState('June 2024');
  const [days] = useState<AttendanceDay[]>(() => {
    return Array.from({ length: 31 }, (_, i) => ({
      date: i + 1,
      status: Math.random() > 0.2 ? 'present' : Math.random() > 0.5 ? 'absent' : 'leave',
    }));
  });

  const getStatusColor = (status: AttendanceDay['status']) => {
    switch (status) {
      case 'present':
        return 'bg-green-100 text-green-700';
      case 'absent':
        return 'bg-red-100 text-red-700';
      case 'leave':
        return 'bg-blue-100 text-blue-700';
      default:
        return 'bg-gray-100';
    }
  };

  return (
    <Layout>
      <Header title="Attendance" />
      <div className="p-4 space-y-6">
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold">20 Days</h3>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <span className="w-3 h-3 rounded-full bg-red-400"></span>
                <span>3 days missed</span>
                <span className="w-3 h-3 rounded-full bg-yellow-400 ml-2"></span>
                <span>2 days holiday</span>
              </div>
            </div>
            <div className="h-12 w-12 rounded-full bg-gray-100 flex items-center justify-center">
              <img
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100"
                alt="Profile"
                className="h-10 w-10 rounded-full"
              />
            </div>
          </div>

          <div className="flex items-center justify-between mb-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg">
              <CalendarIcon size={20} />
            </button>
            <h4 className="font-medium">{selectedMonth}</h4>
            <div className="w-8"></div>
          </div>

          <div className="grid grid-cols-7 gap-2 text-center mb-2">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day) => (
              <div key={day} className="text-sm font-medium text-gray-500">
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {days.map((day, index) => (
              <button
                key={index}
                className={`aspect-square rounded-lg text-sm font-medium ${
                  getStatusColor(day.status)
                }`}
              >
                {day.date}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="bg-green-100 p-4 rounded-xl">
            <div className="text-2xl font-bold text-green-700">25</div>
            <div className="text-sm text-green-600">Present</div>
          </div>
          <div className="bg-red-100 p-4 rounded-xl">
            <div className="text-2xl font-bold text-red-700">2</div>
            <div className="text-sm text-red-600">Absent</div>
          </div>
          <div className="bg-blue-100 p-4 rounded-xl">
            <div className="text-2xl font-bold text-blue-700">1</div>
            <div className="text-sm text-blue-600">Leave</div>
          </div>
        </div>
      </div>
    </Layout>
  );
}