import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function OTPVerification() {
  const [otp, setOtp] = useState(['', '', '', '']);
  const navigate = useNavigate();

  const handleChange = (index: number, value: string) => {
    if (value.length <= 1) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);
      
      if (value && index < 3) {
        const nextInput = document.getElementById(`otp-${index + 1}`);
        nextInput?.focus();
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/dashboard');
  };

  return (
    <div className="mobile-container p-6 flex flex-col justify-center">
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold">Verify Code</h1>
          <p className="text-gray-500 mt-2">
            Check your SMS inbox, we have sent you the code.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex justify-between gap-2">
            {otp.map((digit, index) => (
              <input
                key={index}
                id={`otp-${index}`}
                type="text"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                className="w-14 h-14 text-center text-xl font-bold border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
            ))}
          </div>

          <button type="submit" className="btn-primary w-full">
            Verify
          </button>

          <p className="text-center text-sm">
            Didn't receive the code?{' '}
            <button type="button" className="text-primary font-medium">
              Resend Code
            </button>
          </p>
        </form>
      </div>
    </div>
  );
}