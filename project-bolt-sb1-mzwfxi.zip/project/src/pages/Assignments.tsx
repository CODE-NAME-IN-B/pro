import Layout from '../components/Layout';
import Header from '../components/Header';
import { FileText, Book, PresentationIcon, BarChart3 } from 'lucide-react';

const assignmentTypes = [
  { icon: FileText, label: 'Reports', color: 'indigo' },
  { icon: Book, label: 'Journals', color: 'emerald' },
  { icon: BarChart3, label: 'Projects', color: 'rose' },
  { icon: PresentationIcon, label: 'Presentation', color: 'cyan' },
];

const statusColors = {
  complete: 'bg-green-500',
  individual: 'bg-blue-500',
  group: 'bg-purple-500',
};

export default function Assignments() {
  return (
    <Layout>
      <Header title="Assignments" />
      <div className="p-4 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          {assignmentTypes.map((type) => (
            <div
              key={type.label}
              className="bg-white p-4 rounded-xl shadow-sm border border-gray-100"
            >
              <type.icon
                size={24}
                className={`text-${type.color}-500 mb-2`}
              />
              <h3 className="font-medium">{type.label}</h3>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-xl p-4 shadow-sm">
          <h3 className="font-medium mb-4">Status</h3>
          <div className="space-y-4">
            {Object.entries(statusColors).map(([status, color]) => (
              <div key={status} className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${color}`}></div>
                <span className="capitalize">{status}</span>
                <div className="flex-1 h-2 bg-gray-100 rounded-full">
                  <div
                    className={`h-full ${color} rounded-full`}
                    style={{
                      width: `${Math.floor(Math.random() * 100)}%`,
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}