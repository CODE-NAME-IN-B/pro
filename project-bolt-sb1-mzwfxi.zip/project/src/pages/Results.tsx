import Layout from '../components/Layout';
import Header from '../components/Header';
import { Send } from 'lucide-react';

interface Subject {
  name: string;
  marks: number;
  total: number;
  grade: string;
}

const subjects: Subject[] = [
  { name: 'Mathematics', marks: 85, total: 100, grade: 'A' },
  { name: 'Science', marks: 92, total: 100, grade: 'A+' },
  { name: 'English', marks: 78, total: 100, grade: 'B+' },
  { name: 'History', marks: 88, total: 100, grade: 'A' },
  { name: 'Geography', marks: 82, total: 100, grade: 'A' },
];

export default function Results() {
  return (
    <Layout>
      <Header title="Results" />
      <div className="p-4 space-y-6">
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <div className="flex items-center gap-4 mb-6">
            <img
              src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100"
              alt="Profile"
              className="w-16 h-16 rounded-full"
            />
            <div>
              <h2 className="font-semibold">Sarah Johnson</h2>
              <p className="text-sm text-gray-500">Class X-B • Roll No: 42</p>
            </div>
          </div>

          <div className="space-y-4">
            {subjects.map((subject) => (
              <div
                key={subject.name}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <div>
                  <h3 className="font-medium">{subject.name}</h3>
                  <p className="text-sm text-gray-500">
                    {subject.marks}/{subject.total}
                  </p>
                </div>
                <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-medium">
                  {subject.grade}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-sm">
          <h3 className="font-medium mb-3">Feedback</h3>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Write a comment..."
              className="flex-1 input-field"
            />
            <button className="btn-primary p-2">
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
}