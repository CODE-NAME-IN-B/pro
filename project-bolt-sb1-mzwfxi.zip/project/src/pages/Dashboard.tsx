import Layout from '../components/Layout';
import Header from '../components/Header';
import DashboardCard from '../components/DashboardCard';
import { UserCircle, CalendarCheck, BookOpen, Users, Calendar, Bell } from 'lucide-react';

export default function Dashboard() {
  return (
    <Layout>
      <div className="space-y-6">
        <Header title="Dashboard" showBack={false} />
        
        {/* Banner Section */}
        <div className="px-4 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-primary/10 rounded-xl p-4">
              <h3 className="font-medium mb-2">Sports</h3>
              <p className="text-sm text-gray-600">Annual sports meet registration open</p>
            </div>
            <div className="bg-purple-100 rounded-xl p-4">
              <h3 className="font-medium mb-2">Exam</h3>
              <p className="text-sm text-gray-600">Mid-term exams starting next week</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="px-4">
          <div className="grid grid-cols-2 gap-4">
            <DashboardCard
              icon={UserCircle}
              title="Student Profile"
              to="/profile"
            />
            <DashboardCard
              icon={CalendarCheck}
              title="Attendance"
              to="/attendance"
            />
            <DashboardCard
              icon={BookOpen}
              title="Assessment"
              to="/assignments"
            />
            <DashboardCard
              icon={Users}
              title="Classroom"
              to="/classroom"
            />
            <DashboardCard
              icon={Calendar}
              title="Calendar"
              to="/calendar"
            />
            <DashboardCard
              icon={Bell}
              title="Notice Board"
              to="/notice-board"
            />
          </div>
        </div>
      </div>
    </Layout>
  );
}