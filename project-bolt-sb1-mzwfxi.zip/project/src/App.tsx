import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import OTPVerification from './pages/OTPVerification';
import Dashboard from './pages/Dashboard';
import Attendance from './pages/Attendance';
import NoticeBoard from './pages/NoticeBoard';
import Profile from './pages/Profile';
import Assignments from './pages/Assignments';
import Results from './pages/Results';
import ProgressReport from './pages/ProgressReport';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/verify" element={<OTPVerification />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/attendance" element={<Attendance />} />
          <Route path="/notice-board" element={<NoticeBoard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/assignments" element={<Assignments />} />
          <Route path="/results" element={<Results />} />
          <Route path="/progress-report" element={<ProgressReport />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;