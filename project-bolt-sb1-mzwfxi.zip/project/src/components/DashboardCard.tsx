import { LucideIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

interface DashboardCardProps {
  icon: LucideIcon;
  title: string;
  to: string;
  className?: string;
}

export default function DashboardCard({ icon: Icon, title, to, className = '' }: DashboardCardProps) {
  return (
    <Link
      to={to}
      className={`flex flex-col items-center justify-center p-4 rounded-xl bg-white shadow-sm border border-gray-100 hover:border-primary/20 transition-colors ${className}`}
    >
      <Icon size={24} className="text-primary mb-2" />
      <span className="text-sm font-medium text-gray-700">{title}</span>
    </Link>
  );
}