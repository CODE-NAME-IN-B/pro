import { ChevronLeft, Bell } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface HeaderProps {
  title: string;
  showBack?: boolean;
  showNotification?: boolean;
}

export default function Header({ title, showBack = true, showNotification = true }: HeaderProps) {
  const navigate = useNavigate();
  
  return (
    <header className="flex items-center justify-between p-4 bg-white border-b">
      <div className="flex items-center gap-2">
        {showBack && (
          <button onClick={() => navigate(-1)} className="p-1">
            <ChevronLeft size={24} />
          </button>
        )}
        <h1 className="text-xl font-semibold">{title}</h1>
      </div>
      {showNotification && (
        <button className="p-1">
          <Bell size={24} />
        </button>
      )}
    </header>
  );
}