import { Home, Calendar, Bell, Search, User, Plus } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <div className="mobile-container relative pb-20">
      {children}
      
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t max-w-md mx-auto">
        <div className="flex justify-between px-4 py-2">
          <Link to="/dashboard" className={`nav-icon ${isActive('/dashboard') ? 'text-primary' : 'text-gray-500'}`}>
            <Home size={24} />
          </Link>
          <Link to="/calendar" className={`nav-icon ${isActive('/calendar') ? 'text-primary' : 'text-gray-500'}`}>
            <Calendar size={24} />
          </Link>
          <button className="bg-primary text-white p-3 rounded-full -mt-6">
            <Plus size={24} />
          </button>
          <Link to="/search" className={`nav-icon ${isActive('/search') ? 'text-primary' : 'text-gray-500'}`}>
            <Search size={24} />
          </Link>
          <Link to="/profile" className={`nav-icon ${isActive('/profile') ? 'text-primary' : 'text-gray-500'}`}>
            <User size={24} />
          </Link>
        </div>
      </nav>
    </div>
  );
}